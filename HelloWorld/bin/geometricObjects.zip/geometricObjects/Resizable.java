package geometricObjects;

	public interface Resizable
	{
		void resize(int percentage);
	}

