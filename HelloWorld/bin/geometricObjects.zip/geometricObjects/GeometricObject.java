package geometricObjects;

	public interface GeometricObject
	{
		double getArea() ;
		double getPerimeter();
	}

	
